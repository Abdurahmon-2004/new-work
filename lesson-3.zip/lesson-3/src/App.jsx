import "./Global.css";
import Sidebar from "./Sidebar";

export default function App() {
  return (
    <div className="mx-auto border w-[1470px] bg-[#DCE9F9]">
      <Sidebar />
    </div>
  );
}
